import ast
import typing as t


class BaseExpressionParsingError(Exception):
    pass


class GenericVisitError(BaseExpressionParsingError):
    def __init__(self, node: ast.AST, *args: object) -> None:
        self.node = node
        super().__init__(*args)


class WrongVisitError(BaseExpressionParsingError):
    def __init__(
        self, received: ast.AST, expected: type[ast.AST], *args: object
    ) -> None:
        self.received = received
        self.expected = expected
        super().__init__(*args)


class NotStrConstantError(BaseExpressionParsingError):
    def __init__(self, value: t.Any, *args: t.Any) -> None:
        self.value = value
        super().__init__(*args)


class EmptySrcError(BaseExpressionParsingError):
    pass


class MaxTokenCountExceecedError(BaseExpressionParsingError):
    pass


class MaxSrcLengthExceededError(BaseExpressionParsingError):
    pass


class MaxStringLengthExceededError(BaseExpressionParsingError):
    pass
